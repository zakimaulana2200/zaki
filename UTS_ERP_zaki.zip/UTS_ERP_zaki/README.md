# ERP Praktikum — Laravel 12

Project sumber aplikasi praktikum ERP berdasarkan bagian Praktikum 1–5 pada PDF UTS. Stack: Laravel 12, PHP 8.2+, MySQL/MariaDB, Blade dan Bootstrap 5.

## Modul
1. Integrasi ERP: input pesanan dan alur data departemen.
2. Arsitektur teknis: diagram, matriks hak akses, rencana backup, simulasi gangguan.
3. Proses bisnis: pengajuan bahan dan persetujuan/penolakan.
4. Keuangan: jurnal debit-kredit dan ringkasan saldo akun.
5. SCM: hitung kebutuhan bahan, buat Purchase Order, penerimaan barang, update stok dan jurnal utang.

## Instalasi Windows (XAMPP + VS Code)
1. Ekstrak folder `ERP_Laravel12`.
2. Pastikan PHP 8.2 dan Composer terpasang. Jalankan `php -v` dan `composer -V`.
3. Buat database `erp_praktikum` kosong melalui phpMyAdmin.
4. Salin `.env.example` menjadi `.env`. Pastikan DB_DATABASE=erp_praktikum, DB_USERNAME=root dan DB_PASSWORD sesuai MySQL.
5. Buka terminal pada folder project, lalu jalankan:

```bash
composer install
php artisan key:generate
php artisan migrate --seed
php artisan serve
```

6. Buka `http://127.0.0.1:8000`.

**Alternatif database:** file `database/erp_praktikum.sql` dapat diimpor melalui phpMyAdmin. Jika mengimpor SQL, jangan jalankan `php artisan migrate --seed` pada database yang sama. Gunakan database kosong dan pilih salah satu metode saja.

## Catatan
- Seeder mengisi bahan A (stok 500, lead time 5 hari) dan bahan B (stok 700, lead time 10 hari).
- Praktikum 3 mengizinkan perubahan status permintaan menjadi Disetujui atau Ditolak.
- Praktikum 4 merupakan jurnal sederhana untuk simulasi pembelajaran; belum mencakup chart of accounts lengkap, laporan neraca/laba rugi penuh, atau proses rekonsiliasi.
- Praktikum 5: penerimaan PO menambah stok dan mencatat debit Persediaan serta kredit Utang Usaha.
- Aplikasi ini belum dilengkapi login multi-role, sehingga untuk penggunaan nyata perlu ditambah autentikasi dan otorisasi.
- Bootstrap diambil dari CDN sehingga tampilan memerlukan internet; fungsi backend Laravel dan database berjalan lokal.

## Data awal Praktikum 5 sesuai tabel pada PDF
- Bahan A: stok tersedia 400 unit, PO belum diterima 100 unit, lead time 4 hari kerja.
- Bahan B: stok tersedia 250 unit, PO belum diterima 0 unit, lead time 7 hari kerja.
- Untuk produksi 300 unit: kebutuhan bruto A = 900, kebutuhan bersih A = 900 - 400 - 100 = 400 unit. Kebutuhan bruto B = 600, kebutuhan bersih B = 600 - 250 = 350 unit.
