<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class ErpOrder extends Model { protected $table='erp_orders'; protected $fillable=['customer','product','quantity','delivery_date','status']; }
