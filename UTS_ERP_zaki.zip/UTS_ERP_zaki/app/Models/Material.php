<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Material extends Model { protected $fillable=['code','name','stock','on_order','unit','lead_time_days','price']; }
