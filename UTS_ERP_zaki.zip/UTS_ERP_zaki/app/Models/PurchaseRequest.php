<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class PurchaseRequest extends Model { protected $fillable=['requester','department','material_id','quantity','needed_at','notes','status']; public function material(){return $this->belongsTo(Material::class);} }
