<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class FinanceTransaction extends Model { protected $fillable=['transaction_date','description','account_debit','account_credit','amount','reference']; }
