<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class PurchaseOrder extends Model { protected $fillable=['po_number','supplier','material_id','quantity','unit_price','status','ordered_at','received_at']; public function material(){return $this->belongsTo(Material::class);} }
