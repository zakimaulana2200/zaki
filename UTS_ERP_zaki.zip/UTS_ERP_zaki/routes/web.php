<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ERPController;
Route::get('/', [ERPController::class,'dashboard'])->name('dashboard');
Route::get('/praktikum/{nomor}', [ERPController::class,'show'])->whereNumber('nomor')->name('praktikum.show');
Route::post('/pesanan',[ERPController::class,'storeOrder'])->name('orders.store');
Route::post('/permintaan',[ERPController::class,'storeRequest'])->name('requests.store');
Route::post('/permintaan/{id}/status',[ERPController::class,'updateRequest'])->name('requests.status');
Route::post('/jurnal',[ERPController::class,'storeFinance'])->name('finance.store');
Route::post('/po',[ERPController::class,'storePO'])->name('po.store');
Route::post('/po/{id}/terima',[ERPController::class,'receivePO'])->name('po.receive');
