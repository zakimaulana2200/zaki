
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ERP Praktikum</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #f4f6f9;
            font-family: Arial, sans-serif;
        }
        .sidebar {
            min-height: 100vh;
            background: #212529;
            color: white;
            padding: 25px 15px;
        }
        .sidebar a {
            display: block;
            color: #ddd;
            text-decoration: none;
            padding: 12px;
            border-radius: 6px;
        }
        .sidebar a:hover {
            background: #343a40;
            color: white;
        }
        .content {
            padding: 30px;
        }
    </style>
</head>
<body>

<div class="container-fluid">
    <div class="row">
        <aside class="col-md-2 sidebar">
            <a href="/">Dashboard</a>
<a href="/orders">Sales Order</a>
<a href="/purchase-requests">Purchase Request</a>
<a href="/finance">Finance</a>
<a href="/materials">Materials</a>
        </aside>

        <main class="col-md-10 content">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\UTS_ERP_zaki\resources\views/layouts/app.blade.php ENDPATH**/ ?>