<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder;use App\Models\Material;
class DatabaseSeeder extends Seeder {public function run():void {Material::updateOrCreate(['code'=>'BA-001'],['name'=>'Bahan Baku A','stock'=>400,'on_order'=>100,'unit'=>'unit','lead_time_days'=>4,'price'=>10000]);Material::updateOrCreate(['code'=>'BB-001'],['name'=>'Bahan Baku B','stock'=>250,'on_order'=>0,'unit'=>'unit','lead_time_days'=>7,'price'=>15000]);}}
